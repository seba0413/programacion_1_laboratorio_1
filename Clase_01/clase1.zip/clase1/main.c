#include <stdio.h>
#include <stdlib.h>

int main()
{
    int primerNumero;
    int segundoNumero;
    int resultado;
    char respuesta;

    do
    {
        printf("Dame el primer numero\n");
        scanf("%d",&primerNumero);
        printf("Dame el segundo numero\n");
        scanf("%d",&segundoNumero);
        if(primerNumero>0 && segundoNumero>0)
        {
            resultado = primerNumero + segundoNumero;
            printf("\nEl resultado es: %d",resultado);
        }
        else if (primerNumero > 0 && segundoNumero <= 0)
        {
            printf("\nError en el segundo numero");
        }
        else if (primerNumero <= 0 && segundoNumero > 0)
        {
            printf("\nError en el primer numero");
        }
        else
        {
            printf("\nError");
        }
        printf("Seguis??? (s/n)");
        fflush(stdin);
        scanf("%c",&respuesta);
    }while(respuesta == 's');


    return 0;
}
