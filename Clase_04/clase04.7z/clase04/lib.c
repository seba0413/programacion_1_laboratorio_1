#include <stdio.h>
#include <stdlib.h>

int getInt(int* resultado, char* mensaje, char* mensajeError, int minimo, int maximo, int reintentos)
{
    int retorno = -1;
    long auxiliarLong;
    do
    {
        reintentos--;
        printf("%s", mensaje);
        scanf("%ld", &auxiliarLong);
        if (auxiliarLong >= minimo && auxiliarLong <= maximo)
        {
            *resultado = (int) auxiliarLong;
            retorno = 0;
            break;
        }
        printf("%s", mensajeError);
    } while(reintentos >= 0);
    return retorno;
}

int getFloat(float* resultado, char* mensaje, char* mensajeError, float minimo, float maximo, int reintentos)
{
    int retorno = -1;
    double auxiliarDouble;
    do
    {
        reintentos--;
        printf("%s", mensaje);
        scanf("%f", &auxiliarDouble);
        if (auxiliarDouble >= minimo && auxiliarDouble <= maximo)
        {
            *resultado = auxiliarDouble;
            retorno = 0;
            break;
        }
        printf("%s", mensajeError);
    } while(reintentos >= 0);
    return retorno;
}

int factorial (int numero, long* resultado)
{
    long auxiliarResultado;
    auxiliarResultado = (long) numero;
    while(numero > 1)
    {
        numero--;
        auxiliarResultado = auxiliarResultado * numero;
    }
    *resultado = auxiliarResultado;
    return 0;
}
