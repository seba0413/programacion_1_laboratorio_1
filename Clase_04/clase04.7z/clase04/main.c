#include <stdio.h>
#include <stdlib.h>
#include "lib.h"

int main()
{
    int edad;
    if (getInt(&edad, "Cuantos a�os?", "Error", 0, 199, 2)==0)
    {
        printf("\n La edad es: %d", edad);
    }
    else
    {
        printf("\n Error");
    }
    return 0;
}



