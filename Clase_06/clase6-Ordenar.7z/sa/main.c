#include <stdio.h>
#include <stdlib.h>
#include "sort.h"
int main()
{
    int array[10] = {1,7,2,9,4,6,7,0,3,5};
    if(!sort_ordenarArrayEnteros(array,10,0))
    {
        sort_mostrarArrayEnteros(array, 10);
    }
    return 0;
}
