#include <stdio.h>
#include <stdlib.h>

int sort_ordenarArrayEnteros(int* array, int cantidadElementos, int flagOrden)
{
    int retorno = -1;
    int flagSwap;
    int i;
    int auxiliar;
    do
    {
        flagSwap = 0;
        if  (cantidadElementos > 0)
        {
            retorno = 0;
            for (i = 0; i < cantidadElementos -1; i++)
            {
                if  ((array[i] < array[i+1] && flagOrden) || (array[i] > array[i+1] && !flagOrden))
                {
                    auxiliar = array[i+1];
                    array[i+1] = array[i];
                    array[i] = auxiliar;
                    flagSwap = 1;
                }
            }
        }
    }while (flagSwap);
    return retorno;
}

int sort_mostrarArrayEnteros(int* array, int cantidadElementos)
{
    int i;
    if  (cantidadElementos > 0)
    {
        for (i = 0; i < cantidadElementos; i++)
        {
            printf("%d\n", array[i]);
        }
    }
    else
    {
        printf("Error");
    }
    return 0;
}
