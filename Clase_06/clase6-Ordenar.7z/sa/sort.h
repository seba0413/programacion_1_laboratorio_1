int sort_ordenarArrayEnteros(int* array, int cantidadElementos, int flagOrden);
int sort_mostrarArrayEnteros(int* array, int cantidadElementos);
