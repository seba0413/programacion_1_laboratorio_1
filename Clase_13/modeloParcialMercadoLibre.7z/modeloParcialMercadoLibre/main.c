#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "usuario.h"
#include "publicacion.h"
#define CANTIDADUSUARIOS 100
#define CANTIDADPUBLICACIONES 1000

int main()
{
    Usuario arrayUsuario[CANTIDADUSUARIOS];
    usuario_init(arrayUsuario, CANTIDADUSUARIOS);
    Publicacion arrayPublicacion[CANTIDADPUBLICACIONES];
    publicacion_init(arrayPublicacion, CANTIDADPUBLICACIONES);

    usuario_altaForzada(arrayUsuario, CANTIDADUSUARIOS, "Leandro", "10");
    usuario_altaForzada(arrayUsuario, CANTIDADUSUARIOS, "Juan", "5");
    usuario_altaForzada(arrayUsuario, CANTIDADUSUARIOS, "Nahuel", "28");

    publicacion_altaForzada(arrayPublicacion, CANTIDADPUBLICACIONES, "Libro",10,5,1,2);
    publicacion_altaForzada(arrayPublicacion, CANTIDADPUBLICACIONES, "Computadora",500,30,2,6);
    publicacion_altaForzada(arrayPublicacion, CANTIDADPUBLICACIONES, "Celular",300,8,1,3);

    int menu;
    int idUsuario;
    int idProducto;

    do
    {
        getValidInt("\n1.Alta de Usuario\n2.Modificar datos de Usuario\n3.Baja de usuario\n4.Publicar producto\n5.Modificar Publicacion\n6.Cancelar Publicacion\n7.Comprar producto\n8.Listar publicaciones de usuario\n9.Listar publicaciones\n10.Listar usuarios\n11.Salir\n","\nOpcion invalida\n",&menu,1,11,1);
        switch(menu)
        {
            case 1:
                usuario_alta(arrayUsuario,CANTIDADUSUARIOS);
                break;
            case 2:
                getValidInt("\nIngrese Id: \n","\nId invalido\n",&idUsuario,0,999,2);
                usuario_modificacion(arrayUsuario, CANTIDADUSUARIOS, idUsuario);
                break;
            case 3:
                getValidInt("\nIngrese Id: \n","\nId invalido\n",&idUsuario,0,999,2);
                usuario_baja(arrayUsuario, CANTIDADUSUARIOS, idUsuario);
                publicacion_bajaPublicacionesDeUsuario(arrayPublicacion, CANTIDADPUBLICACIONES, idUsuario);
                break;
            case 4:
                getValidInt("\nIngrese Id: \n","\nId invalido\n",&idUsuario,0,999,2);
                publicacion_alta(arrayPublicacion, CANTIDADPUBLICACIONES, idUsuario);
                break;
            case 5:
                getValidInt("\nIngrese Id: \n","\nId invalido\n",&idUsuario,0,999,2);
                publicacion_mostrar(arrayPublicacion, CANTIDADPUBLICACIONES, idUsuario);
                getValidInt("\nIngrese Id del producto: \n","\nId invalido\n",&idProducto,0,999,2);
                publicacion_modificacion(arrayPublicacion, CANTIDADPUBLICACIONES, idProducto);
                break;
            case 6:
                getValidInt("\nIngrese Id: \n","\nId invalido\n",&idUsuario,0,999,2);
                publicacion_mostrar(arrayPublicacion, CANTIDADPUBLICACIONES, idUsuario);
                getValidInt("\nIngrese Id del producto: \n","\nId invalido\n",&idProducto,0,999,2);
                publicacion_baja(arrayPublicacion, CANTIDADPUBLICACIONES, idProducto);
                break;
            case 7:
                getValidInt("\nIngrese Id del producto: \n","\nId invalido\n",&idProducto,0,999,2);
                publicacion_comprarProducto(arrayPublicacion, CANTIDADPUBLICACIONES, arrayUsuario, CANTIDADUSUARIOS, idProducto);
                break;
            case 8:
                getValidInt("\nIngrese Id de Usuario: \n","\nId invalido\n",&idUsuario,0,999,2);
                publicacion_listarPublicacionesDeUsuario(arrayPublicacion, CANTIDADPUBLICACIONES, idUsuario);
                break;
        }

    }while(menu != 11);

    return 0;
}
