#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "publicacion.h"
#include "usuario.h"
#include "utn.h"

//int buscarLugarLibre(Publicacion* array,int limite);
//int proximoId();

int proximoIdPublicacion();

/** \brief
 * \param array Publicacion*
 * \param limite int
 * \return int
 *
 */
int publicacion_init(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            array[i].isEmpty=1;
        }
    }
    return retorno;
}

int publicacion_mostrarDebug(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            printf("[DEBUG] - %d - %s - %d\n",array[i].idProducto, array[i].nombre, array[i].isEmpty);
        }
    }
    return retorno;
}

int publicacion_mostrar(Publicacion* array,int limite, int idUsuario)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(array[i].idUsuario == idUsuario)
                printf("[RELEASE] - %d - %s - %f - %d - %d\n",array[i].idProducto, array[i].nombre, array[i].precio, array[i].cantidadVendida, array[i].stock);
        }
    }
    return retorno;
}

int publicacion_alta(Publicacion* array,int limite, int idUsuario)
{
    int retorno = -1;
    int i;
    char auxiliarNombre[50];
    float auxiliarPrecio;
    int auxiliarStock;
    if(limite > 0 && array != NULL)
    {
        i = buscarLugarLibre(array,limite);
        if(i >= 0)
        {
            if(!getValidString("\nNombre? ","\nEso no es un nombre","El maximo es 50",auxiliarNombre,50,2))
            {
                if(getValidFloat("\nIngrese precio: \n", "\nPrecio invalido\n", &auxiliarPrecio,1,999999,2))
                {
                    if(getValidInt("\nIngrese stock: \n", "\nStock invalido\n", &auxiliarStock, 1, 999999,2))
                    {
                        retorno = 0;
                        strcpy(array[i].nombre,auxiliarNombre);
                        array[i].precio = auxiliarPrecio;
                        array[i].stock = auxiliarStock;
                        array[i].cantidadVendida = 0;
                        array[i].idUsuario = idUsuario;
                        array[i].idProducto = proximoIdPublicacion();
                        array[i].isEmpty = 0;
                    }
                }
            }
        }
    }
    return retorno;
}

int publicacion_altaForzada(Publicacion* array,int limite, char* nombre, float precio, int stock, int idUsuario, int cantidadVendida)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        i = buscarLugarLibre(array,limite);
        if(i >= 0)
        {
            retorno = 0;
            strcpy(array[i].nombre,nombre);
            array[i].precio = precio;
            array[i].stock = stock;
            array[i].idUsuario = idUsuario;
            array[i].cantidadVendida = cantidadVendida;
            array[i].idProducto = proximoIdPublicacion();
            array[i].isEmpty = 0;
        }
    }
    return retorno;
}

int publicacion_comprarProducto(Publicacion* array, int limite, Usuario* arrayUsuario, int limiteUsuario, int idProducto)
{
    int retorno = -1;
    int i;
    int indiceUsuario;
    int auxiliarCalificacion;
    if(limite > 0 && array != NULL)
    {
        for(i = 0; i < limite; i++)
        {
            if (!array[i].isEmpty && array[i].stock > 0)
            {
                array[i].cantidadVendida++;
                indiceUsuario = usuario_buscarPorId(arrayUsuario, limiteUsuario,array[i].idUsuario);
                getValidInt("\nIngrese calificacion: \n", "\nCalificacion Invalida\n", &auxiliarCalificacion,1,10,2);
                arrayUsuario[indiceUsuario].acumuladorDeCalificaciones += auxiliarCalificacion;
                arrayUsuario[indiceUsuario].cantidadDeCalificaciones++;
                retorno = 0;
            }
        }
    }
    return retorno;
}

int publicacion_baja(Publicacion* array,int limite, int idProducto)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idProducto==idProducto)
            {
                array[i].isEmpty = 1;
                retorno = 0;
                break;
            }
        }
    }
    return retorno;
}

int publicacion_bajaPublicacionesDeUsuario(Publicacion* array,int limite, int idUsuario)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idUsuario==idUsuario)
            {
                array[i].isEmpty = 1;
                retorno = 0;
                break;
            }
        }
    }
    return retorno;
}


int publicacion_modificacion(Publicacion* array,int limite, int idProducto)
{
    int retorno = -1;
    int i;
    float auxiliarPrecio;
    int auxiliarStock;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idProducto==idProducto)
            {
                if(!getValidFloat("\nIngrese precio: \n", "\nPrecio invalido\n", &auxiliarPrecio,1,999999,2))
                {
                    if (!getValidInt("\nIngrese stock: \n", "\nStock invalido\n", &auxiliarStock,1,999999,2))
                    {
                        retorno = 0;
                        array[i].precio = auxiliarPrecio;
                        array[i].stock = auxiliarStock;
                    }
                }
            }
        }
    }
    return retorno;
}

int publicacion_listarPublicacionesDeUsuario(Publicacion* array, int limite, int idUsuario)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for (i = 0; i < limite; i++)
        {
            if (array[i].idUsuario == idUsuario)
            {
                printf("\nId de producto: %d\nNombre: %s\nPrecio: %f\nCantidad Vendida: %d\nStock: %d\n",
                       array[i].idProducto, array[i].nombre, array[i].precio, array[i].cantidadVendida, array[i].stock);
            }
        }
    }
    return retorno;
}

int publicacion_ordenar(Publicacion* array,int limite, int orden)
{
    int retorno = -1;
    int i;
    int flagSwap;
    Publicacion auxiliarEstructura;

    if(limite > 0 && array != NULL)
    {
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                if(!array[i].isEmpty && !array[i+1].isEmpty)
                {
                    if((strcmp(array[i].nombre,array[i+1].nombre) > 0 && orden) || (strcmp(array[i].nombre,array[i+1].nombre) < 0 && !orden)) //******
                    {
                        auxiliarEstructura = array[i];
                        array[i] = array[i+1];
                        array[i+1] = auxiliarEstructura;
                        flagSwap = 1;
                    }
                }
            }
        }while(flagSwap);
    }
    return retorno;
}

/*int buscarLugarLibre(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(array[i].isEmpty==1)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}*/

int proximoIdPublicacion()
{
    static int proximoId = -1;
    proximoId++;
    return proximoId;
}


