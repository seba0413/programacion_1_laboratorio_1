#ifndef PUBLICACION_H_INCLUDED
#define PUBLICACION_H_INCLUDED

typedef struct
{
    char nombre[50];
    float precio;
    int stock;
    int idUsuario;
    int cantidadVendida;
    int idProducto;
    int isEmpty;
}Publicacion;

int publicacion_init(Publicacion* array,int limite);
int publicacion_mostrar(Publicacion* array,int limite, int idUsuario);
int publicacion_alta(Publicacion* array,int limite, int idUsuario);
int publicacion_altaForzada(Publicacion* array,int limite, char* nombre, float precio, int stock, int idUsuario, int cantidadVendida);
int publicacion_baja(Publicacion* array,int limite, int id);
int publicacion_bajaPublicacionesDeUsuario(Publicacion* array,int limite, int idUsuario);
int publicacion_modificacion(Publicacion* array,int limite, int idProducto);
int publicacion_ordenar(Publicacion* array,int limite, int orden);


#endif // PUBLICACION_H_INCLUDED

