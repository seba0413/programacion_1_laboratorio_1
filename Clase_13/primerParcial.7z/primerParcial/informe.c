#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "cliente.h"
#include "utn.h"
#include "publicacion.h"

int informe_imprimirClientes(Cliente* arrayC, int limiteC, Publicacion* arrayP, int limiteP)
{
    int retorno = -1;
    int i;
    int avisos;
    if(limiteC > 0 && limiteC > 0 && arrayC != NULL && arrayP != NULL)
    {
        retorno = 0;
        for(i=0; i<limiteC; i++)
        {
            if(!arrayC[i].isEmpty)
            {
                avisos = publicacion_informarAvisosActivos(arrayP,limiteP, arrayC[i].idCliente);
                printf("\nId cliente: %d\nNombre: %s\nApellido: %s\nCantidad de avisos: %d\n",
                       arrayC[i].idCliente, arrayC[i].nombre, arrayC[i].apellido, avisos);
            }
        }

    return retorno;
    }
}

int informe_imprimirPublicaciones(Publicacion* arrayP, int limiteP, Cliente* arrayC, int limiteC)
{
    int retorno = -1;
    int i;
    int indice;
    if(limiteC > 0 && limiteC > 0 && arrayC != NULL && arrayP != NULL)
    {
        retorno = 0;
        for (i = 0; i<limiteP; i++)
        {
            if(!arrayP[i].isEmpty && arrayP[i].estado == 1)
            {
                indice = cliente_buscarPorId(arrayC, limiteC, arrayP[i].idCliente);
                printf("\nId cliente: %d\nRubro: %d\nTexto: %s\nCuit: %s\n", arrayP[i].idCliente,
                       arrayP[i].numeroDeRubro, arrayP[i].texto, arrayC[indice].cuit);
            }
        }
    }
    return retorno;
}
