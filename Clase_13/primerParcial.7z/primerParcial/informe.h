#ifndef INFORME_H_INCLUDED
#define INFORME_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "cliente.h"
#include "utn.h"
#include "publicacion.h"

int informe_imprimirClientes(Cliente* arrayC, int limiteC, Publicacion* arrayP, int limiteP);
int informe_imprimirPublicaciones(Publicacion* arrayP, int limiteP, Cliente* arrayC, int limiteC);

#endif // INFORME_H_INCLUDED
