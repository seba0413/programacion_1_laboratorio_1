#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "cliente.h"
#include "publicacion.h"
#include "utn.h"
#include "informe.h"

#define CANTCLIENTES 100
#define CANTPUBLI 1000


int main()
{
    int menu;
    int id;

    Cliente clientes[100];
    cliente_init(clientes, CANTCLIENTES);
    cliente_altaForzada(clientes,CANTCLIENTES, "Juan", "Perez", "20334445556", 1);
    cliente_altaForzada(clientes,CANTCLIENTES, "Pedro", "Gimenez", "20224445556", 2);
    cliente_altaForzada(clientes,CANTCLIENTES, "Ignacio", "Mascare�o", "20114445556", 4);
    cliente_altaForzada(clientes,CANTCLIENTES, "Vida", "Alvarez", "20774445556", 3);
    cliente_altaForzada(clientes,CANTCLIENTES, "Rocio", "Areco", "20994445556", 5);

    Publicacion publicaciones[1000];
    publicacion_init(publicaciones, CANTPUBLI);
    publicacion_altaForzada(publicaciones, CANTPUBLI, 1,2,"texto",0,1);
    publicacion_altaForzada(publicaciones, CANTPUBLI, 3,1,"texto1",1,2);
    publicacion_altaForzada(publicaciones, CANTPUBLI, 2,3,"texto2",0,3);
    publicacion_altaForzada(publicaciones, CANTPUBLI, 5,2,"texto3",0,4);
    publicacion_altaForzada(publicaciones, CANTPUBLI, 4,1,"texto4",1,5);

    do
    {
        getValidInt("\n1.Alta de cliente\n2.Modificar datos de cliente\n3.Baja de cliente\n4.Publicar\n5.Pausar Publicacion\n6.Reanudar Publicacion Debug\n7.Imprimir Clientes\n8.Imprimir publicaciones\n9.Informar Clientes\n10.Informar publicaciones\n11.Salir\n","\nNo valida\n",&menu,1,11,1);
        switch(menu)
        {
            case 1:
                cliente_alta(clientes, CANTCLIENTES);
                break;
            case 2:
                getValidInt("Id?","Id invalido", &id,1,999999,2);
                cliente_modificacion(clientes, CANTCLIENTES,id);
                break;
            case 3:
                getValidInt("Id?","Id invalido", &id,1,999999,2);
                cliente_baja(clientes, CANTCLIENTES,id);
                break;
            case 4:
                publicacion_alta(publicaciones, CANTPUBLI);
                break;
            case 5:
                getValidInt("Id?","Id invalido", &id,1,999999,2);
                publicacion_pausarPublicacion(publicaciones, CANTPUBLI, id, clientes, CANTCLIENTES);
                break;
            case 6:
                getValidInt("Id?","Id invalido", &id,1,999999,2);
                publicacion_reanudarPublicacion(publicaciones, CANTPUBLI, id, clientes, CANTCLIENTES);
                break;
            case 7:
                informe_imprimirClientes(clientes, CANTCLIENTES, publicaciones, CANTPUBLI);
                break;
            case 8:
                informe_imprimirPublicaciones(publicaciones, CANTPUBLI, clientes, CANTCLIENTES);
                break;
            case 9:

                break;
            case 10:

                break;
        }

    }while(menu != 11);


    return 0;
}
