#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "publicacion.h"
#include "utn.h"
#include "cliente.h"

/** \brief Inicializa un array Publicacion
 * \param array Publicacion*
 * \param limite int
 * \return int 0 Ok, -1 Error
 *
 */
int publicacion_init(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            array[i].isEmpty=1;
        }
    }
    return retorno;
}
/** \brief Imprime los valores cargados
 *
 * \param Publicacion array
 * \param int limite
 * \return 0 Ok, -1 Error
 *
 */

int publicacion_mostrarDebug(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            printf("[DEBUG] - %d - %s - %d\n",array[i].idPublicacion, array[i].texto, array[i].isEmpty);
        }
    }
    return retorno;
}
/** \brief Muestra por consola los datos requeridos
 *
 * \param Publicacion array
 * \param int limite
 * \return int 0 ok, -1 Error
 *
 */

int publicacion_mostrar(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
                printf("[RELEASE] - %d - %s - %d\n",array[i].idPublicacion, array[i].texto, array[i].isEmpty);
        }
    }
    return retorno;
}

/** \brief Da de alta elementos Publicacion harcodeados
 *
 * \param Publicacion array
 * \param int limite
 * \param char texto
 * \return 0 ok, -1 Error
 *
 */

int publicacion_altaForzada(Publicacion* array,int limite, int idCliente, int rubro, char* texto, int estado, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        i = buscarLugarLibrePublicacion(array,limite);
        if(i >= 0)
        {
            retorno = 0;
            strcpy(array[i].texto,texto);
            array[i].idCliente = idCliente;
            array[i].idPublicacion = id;
            array[i].numeroDeRubro = rubro;
            array[i].estado = estado;
            array[i].isEmpty = 0;
        }
    }
    return retorno;
}
/** \brief Da el alta de elementos de tipo Publicacion
 *
 * \param Publicacion array
 * \param int limite
 * \return 0 ok, -1 Error
 *
 */


int publicacion_alta(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    int auxiliarId;
    int auxiliarRubro;
    char auxiliarTexto[64];
    if(limite > 0 && array != NULL)
    {
        i = buscarLugarLibrePublicacion(array,limite);
        if(i >= 0)
        {
            if(!getValidInt("Id de Cliente?", "Id invalido", &auxiliarId,1,999999,2))
            {
                if(!getValidInt("Numero rubro?", "Numero invalido", &auxiliarRubro,1,3,2))
                {
                    if(getValidString("Texto del aviso?", "Texto invalido", "Caracteres maximos 64", auxiliarTexto,64,2))
                    {
                        retorno = 0;
                        strcpy(array[i].texto,auxiliarTexto);
                        array[i].idCliente = auxiliarId;
                        array[i].numeroDeRubro = auxiliarRubro;
                        array[i].idPublicacion = proximoIdPublicacion();
                        array[i].estado = 1;
                        array[i].isEmpty = 0;
                    }
                }
            }
        }
        if(!retorno)
        {
            printf("Id del aviso: %d", array[i].idPublicacion);
        }
    }
    return retorno;
}

int publicacion_pausarPublicacion(Publicacion* array, int limite, int id, Cliente* arrayC, int limiteC)
{
    int retorno = -1;
    int i;
    int indice;
    char auxConfirmacion;

    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idPublicacion==id)
            {
                indice = cliente_buscarPorId(arrayC, limiteC,array[i].idCliente);
                printf("Id cliente: %d, Nombre: %s, Apellido: %s", array[i].idCliente, arrayC[indice].nombre, arrayC[indice].apellido);
                printf("Pausar publicacion? (s/n");
                scanf("%c", &auxConfirmacion);
                if (auxConfirmacion == 's')
                {
                    array[i].estado = 0;
                }
            }
        }
    }
    return retorno;
}

int publicacion_reanudarPublicacion(Publicacion* array, int limite, int id, Cliente* arrayC, int limiteC)
{
    int retorno = -1;
    int i;
    int indice;
    char auxConfirmacion;

    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idPublicacion==id)
            {
                indice = cliente_buscarPorId(arrayC, limiteC,array[i].idCliente);
                printf("Id cliente: %d, Nombre: %s, Apellido: %s", array[i].idCliente, arrayC[indice].nombre, arrayC[indice].apellido);
                printf("Reanudar publicacion? (s/n");
                scanf("%c", &auxConfirmacion);
                if (auxConfirmacion == 's')
                {
                    array[i].estado = 1;
                }
            }
        }
    }
    return retorno;
}




/** \brief Elimina los elementos requeridos
 *
 * \param Publicacion array
 * \param int limite
 * \param int id
 * \return 0 ok, -1 Error
 *
 */

int publicacion_baja(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idPublicacion==id)
            {
                array[i].isEmpty = 1;
                retorno = 0;
                break;
            }
        }
    }
    return retorno;
}

/** \brief Modifica los datos de un elemento Publicacion
 *
 * \param Publicacion array
 * \param int limite
 * \param int id
 * \return 0 ok, -1 Error
 *
 */

int publicacion_modificacion(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    char buffer[50];
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idPublicacion==id)
            {
                if(!getValidString("\nNombre? ","\nEso no es un texto","El maximo es 40",buffer,40,2))
                {
                    retorno = 0;
                    strcpy(array[i].texto,buffer);
                    //------------------------------
                    //------------------------------
                }
                else
                {
                    retorno = -3;
                }
                retorno = 0;
                break;
            }
        }
    }
    return retorno;
}

/** \brief Ordena un array de elementos Publicacion
 *
 * \param Publicacion array
 * \param int limite
 * \param int orden
 * \return 0 ok, -1 Error
 *
 */


int publicacion_ordenar(Publicacion* array,int limite, int orden)
{
    int retorno = -1;
    int i;
    int flagSwap;
    Publicacion auxiliarEstructura;

    if(limite > 0 && array != NULL)
    {
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                if(!array[i].isEmpty && !array[i+1].isEmpty)
                {
                    if((array[i].idCliente > array[i+1].idCliente && orden) || (array[i].idCliente < array[i+1].idCliente && !orden))
                    {
                        auxiliarEstructura = array[i];
                        array[i] = array[i+1];
                        array[i+1] = auxiliarEstructura;
                        flagSwap = 1;
                    }
                }
            }
        }while(flagSwap);
    }
    return retorno;
}

/** \brief Pide un id y busca el elemento Publicacion que coincide con ese id
 *
 * \param Publicacion array
 * \param int limite
 * \param int id
 * \return 0 ok, -1 Error
 *
 */

int publicacion_buscarPorId(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idPublicacion==id)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}

/** \brief Busca un lugar libre en un array Publicacion
 *
 * \param Publicacion array
 * \param int limite
 * \return 0 ok, -1 Error
 *
 */

int buscarLugarLibrePublicacion(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(array[i].isEmpty==1)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}

/** \brief Guarda el valor del ultimo id y obtiene el proximo id libre
 *
 * \param void
 * \return int proximoId
 *
 */

int proximoIdPublicacion()
{
    static int proximoId = 0;
    proximoId++;
    return proximoId;
}

int publicacion_informarAvisosActivos(Publicacion* arrayP, int limiteP, int id)
{
    int i;
    int retorno = -1;
    int cantidadAvisosActivos = 0;
    if(limiteP > 0  && arrayP != NULL)
    {
        for (i = 0; i < limiteP; i++)
        {
            if (arrayP[i].idCliente == id && arrayP[i].estado == 1)
            {
                cantidadAvisosActivos++;
            }
        }
        retorno = cantidadAvisosActivos;

    }
    return retorno;
}
