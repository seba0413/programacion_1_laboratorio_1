#ifndef PUBLICACION_H_INCLUDED
#define PUBLICACION_H_INCLUDED
#include "cliente.h"


typedef struct
{
    int idCliente;
    int numeroDeRubro;
    char texto[64];
    int estado;
    int idPublicacion;
    int isEmpty;
}Publicacion;

int publicacion_init(Publicacion* array,int limite);
int publicacion_mostrar(Publicacion* array,int limite);
int publicacion_mostrarDebug(Publicacion* array,int limite);
int publicacion_altaForzada(Publicacion* array,int limite, int idCliente, int rubro, char* texto, int estado, int id);
int publicacion_alta(Publicacion* array,int limite);
int publicacion_pausarPublicacion(Publicacion* array, int limite, int id, Cliente* arrayC, int limiteC);
int publicacion_reanudarPublicacion(Publicacion* array, int limite, int id, Cliente* arrayC, int limiteC);
int publicacion_baja(Publicacion* array,int limite, int id);
int publicacion_modificacion(Publicacion* array,int limite, int id);
int publicacion_ordenar(Publicacion* array,int limite, int orden);
int publicacion_buscarPorId(Publicacion* array,int limite, int id);
int buscarLugarLibrePublicacion(Publicacion* array,int limite);
int proximoIdPublicacion();
int publicacion_informarAvisosActivos(Publicacion* arrayP, int limiteP, int id);

#endif // PUBLICACION_H_INCLUDED

