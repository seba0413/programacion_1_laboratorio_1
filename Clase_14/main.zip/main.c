#include <stdio.h>
#include <stdlib.h>
#include "persona.h"


int main()
{

    Persona* arrayPunterosPersona[50];
    Persona* auxiliarPersona;
    int i;
    int auxEdad;

    Persona Juan;
    Juan.setEdad(&Juan,22);


    for(i=0;i<50;i++)
    {
        auxiliarPersona = persona_new();
        persona_setEdad(auxiliarPersona,20+i);
        arrayPunterosPersona[i]=auxiliarPersona;
    }
    for(i=0;i<50;i++)
    {
        persona_getEdad(arrayPunterosPersona[i],&auxEdad);
        printf("Mem: %p - Edad: %d\n",arrayPunterosPersona[i],auxEdad);
    }


    return 0;
}
