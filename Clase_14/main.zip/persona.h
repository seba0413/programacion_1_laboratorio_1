
typedef struct
{
    int edad;
    char nombre[50];
    int idPersona;
    int(*setEdad)(void*,int);
}Persona;

int validarEdad(int edad);
void persona_delete(Persona* this);
Persona* persona_new();
int persona_setEdad(Persona* this,int edad);
int persona_getEdad(Persona* this,int* edad);
int persona_getNombre(Persona* this,char* nombre);
